﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

public class Bank
{
    // gjort av ahmad su21
    public static void Main()
    {
        string username = " ";
        Console.WriteLine("what is your name: ");
        username = Console.ReadLine();
        BankAccount newAccount = new BankAccount(username, 1000);
    }
}

public class BankAccount : Bank
{
    List<double> DepositList = new List<double>();
    List<double> withdrawtList = new List<double>();
    public string username { get; set; }

    public double Balance { get; set; }

    public BankAccount(string username, double Balance)
    {
        this.username = username;
        this.Balance = Balance;

        Console.WriteLine("username: {0} , balance: {1}", username, Balance);
        NextMenu();
    }

    public void NextMenu()
    {
        double balance = Balance;
        Console.WriteLine("enter 1 for withdraw, 2 for deposit, 3 to logout, 4 for deposit history, 5 for withdrawHistory ");
        string StringMenu = Console.ReadLine();
        int NextChoice = Convert.ToInt32(StringMenu);
        switch (NextChoice)
        {
            case 1:
                Withdraw();
                break;
            case 2:
                Deposit();
                break;
            case 3:
                Logout();
                break;
            case 4:
                DepositHistory();
                break;
            case 5:
                withdrawHistory();
                break;
        }
    }

    public double Withdraw()
    {
        Console.WriteLine("available balance: {0}", Balance);
        Console.WriteLine("how much do you want to withdraw?: ");
        double WithdrawAmt = Convert.ToDouble(Console.ReadLine());

        withdrawtList.Add(WithdrawAmt);
        Balance = Balance -= WithdrawAmt;
        Console.WriteLine("you have " + Balance + " SEK left in your account, " + username + ".");
        NextMenu();
        return WithdrawAmt;
    }

    public double Deposit()
    {
        Console.WriteLine("available balance: {0}", Balance);
        Console.WriteLine("how much do you want to deposit?: ");
        double DepositAmt = Convert.ToDouble(Console.ReadLine());


        DepositList.Add(DepositAmt);

        Balance = Balance + DepositAmt;
        Console.WriteLine("now you have " + Balance + " SEK in your account, " + username + ".");
        NextMenu();
        return DepositAmt;
    }

    public void Logout()
    {
        Console.WriteLine("see you again: " + username);
    }

    public void DepositHistory()
    {
        string path = @"C:\Users\apods\source\repos\bank\1.txt";

        string createText = "File transaction" + username + ", your deposit history:" + Environment.NewLine;
        File.WriteAllText(path, createText);
        foreach (double i in DepositList)
        {
            Console.WriteLine("deposit history: " + i);
            string s = i + Environment.NewLine;
            File.AppendAllText(path, s);
            string readText = File.ReadAllText(path);

            Console.WriteLine(readText);
        }
    }

    public void withdrawHistory()
    {
        string path = @"C:\Users\apods\source\repos\bank\2.txt";

        string createText = "File transaction" + username + ", your withdraw history:" + Environment.NewLine;
        File.WriteAllText(path, createText);
        foreach (double i in withdrawtList)
        {
            Console.WriteLine("withdraw history: " + i);
            string s = i + Environment.NewLine;
            File.AppendAllText(path, s);
            string readText = File.ReadAllText(path);

            Console.WriteLine(readText);
        }
    }

}